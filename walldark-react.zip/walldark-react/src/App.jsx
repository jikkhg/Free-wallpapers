export default function WallpaperSite() {
  const wallpapers = [
    {
      title: "Cyber City",
      category: "Dark",
      image:
        "https://images.unsplash.com/photo-1519608487953-e999c86e7455?q=80&w=1200&auto=format&fit=crop",
    },
    {
      title: "Neon Night",
      category: "AMOLED",
      image:
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1200&auto=format&fit=crop",
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <header className="border-b border-white/10 bg-black/80">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <h1 className="text-2xl font-bold tracking-wide">
            WALL<span className="text-gray-400">DARK</span>
          </h1>

          <input
            type="text"
            placeholder="ค้นหาวอลเปเปอร์..."
            className="w-full max-w-md bg-white/10 border border-white/10 rounded-2xl px-4 py-2 outline-none"
          />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        {wallpapers.map((wallpaper, index) => (
          <div
            key={index}
            className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden"
          >
            <img
              src={wallpaper.image}
              className="w-full h-72 object-cover"
            />

            <div className="p-5">
              <h2 className="text-2xl font-bold">{wallpaper.title}</h2>
              <p className="text-gray-400">{wallpaper.category}</p>

              <button className="mt-4 bg-white text-black px-5 py-2 rounded-2xl font-semibold">
                ดาวน์โหลด
              </button>
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}
