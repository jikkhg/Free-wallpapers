import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import WallpaperSite from "./App";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <WallpaperSite />
  </React.StrictMode>
);
